/*******************************************/
/*             JOURNEY.JS                  */
/*     Datos para USER JOURNEY MAP         */   
/*          [DIU] UX Toolkit v1.0 2019     */                        
/*          ver 1.1 26/Feb/2022            */
/*******************************************/
    
/****  README:       */
/****  v.1.1 Incluye nombre de tu grupo de prácticas (Grupo.ID), curso académico y enlace a github ***/
/****  Modifica los datos para los Journey Map (uno para cada Persona)  */
/****  Usa los 6 pasos y sigue las instrucciones */   
/****  Las imagenes para  'Photo', 'feelX', 'imaX' están en carpeta ./photos **/
/****  Si se usan nuevas imágenes se deben añadir a esa carpeta **/
/****  Los valores de rating están entre 1..5 **/
/****  recursos de imágenes:  https://www.vectorstock.com/royalty-free-vectors/vectors-by_zdeneksasek ***/




angular.module("angular", [])
	.controller("controller", ["$scope", function($scope) { 
		$scope.Grupo_ID ="DIU1.ABCDEF";
        $scope.Curso ="2021/22";
        $scope.Github_ID ="https://github.com/mgea/UX-DIU-Toolkit";
        
		$scope.JourneyIndex = 0;
        
        $scope.Journeys = [
			{		
                
                /*************************************/
                /**** PRIMER USER JOURNEY MAP  *******/
                /*** Cambiar datos             *******/
                /*************************************/
                
				Id: 0,
				Name: "Juan López",
                Photo: "juan.png",
    
                /*** PASO #1: INSPIRACION ***/ 
                goal1: "Quiere viajar a Granada para postear el viaje en su cuenta de Instagram",
                touch1: "Móvil (agenda)",
                feel1: "4",
                con1: "Ver si puede llevar a su hijo al viaje",
                ima1: "hombretablet.jpg",
				
                /*** PASO #2: DECICION ***/ 
                goal2: "Busca alojamientos baratos por Internet",
                touch2: "Movil",
                feel2: "3",
                con2: "No encuentra precios baratos en hoteles, aunque encuentra hostales",
                ima2: "hombremovilenfado.webp",
                
                /*** PASO #3: ACTUA ***/ 
                
                goal3: "Encuentra el Hostel4U a buen precio y pregunta a la madre de su hijo si va a estar disponible (no lo está)",
                touch3: "móvil (llama a su ex)",
                feel3: "1",
                con3: "No puede llevarse a su hijo",
                ima3: "hombrediscutiendo.webp",
                
                /*** PASO #4: OBSERVA ***/ 
                
                goal4: "Busca más hostels para comparar ubicación y precio, basándose en opiniones de otros influencers",
                touch4: "Móvil",
                feel4: "4",
                con4: "Encuentra demasiadas opciones, se le hace difícil elegir.",
                ima4: "hombrefeliz.jpg",
                
                 /*** PASO #5: ANALIZA ***/ 
                
                goal5: "Encuentra dos opciones: Hostel4U y Oripando Hostel",
                touch5: "móvil (Instagram)",
                feel5: "4",
                con5: "Se fija en otros influencers para hacer la decisión final",
                ima5: "hombrefeliz.jpg",
                
                
                /*** PASO #6: CONCLUSION ***/ 
                
                goal6: "Acaba reservando el Hostel4U porque le llama más la zona común",
                touch6: "móvil",
                feel6: "3",
                con6: "No ha podido pillar una promoción, así que le ha salido un poco más caro de lo esperado.",
                ima6: "hombremelancolico.webp",
                
			},
			{	
                /*************************************/
                /**** SEGUNDO USER JOURNEY MAP *******/
                /***      Cambiar datos        *******/
                /*************************************/
                
				Id: 1,
				Name: "Priscilla Russel",
                Photo: "priscilla.png",
                
				 /*** PASO #1: INSPIRACION ***/ 
                goal1: "Quiere ver a su amigo de España",
                touch1: "móvil (whatsapp)",
                feel1: "5",
                con1: "Tiene que encontrar una fecha compatible con su amigo",
                ima1: "movilfeliz.jpg",
                
                /*** PASO #2: DECICION ***/ 
                goal2: "Busca en internet ofertas para la fecha que han acordado",
                touch2: "Ordenador",
                feel2: "1",
                con2: "Tiene complicaciones a la hora de buscar alojamiento",
                ima2: "ordenadorenfadada.webp",
                
                /*** PASO #3: ACTUA ***/ 
                
                goal3: "Su amigo le sugiere alojarse en un hostel",
                touch3: "Móvil (whastapp)",
                feel3: "2",
                con3: "Tiene que compartir habitación con más personas",
                ima3: "chicamovil.jpg",
                
                /*** PASO #4: OBSERVA ***/ 
                
                goal4: "Encuentra el hostel4U, que está cerca de la casa de su amigo.",
                touch4: "Ordenador",
                feel4: "3",
                con4: "Encuentra problemas con la visualización de la página y no se entera muy bien",
                ima4: "ordenadorconfusa.webp",
                
                 /*** PASO #5: ANALIZA ***/ 
                
                goal5: "Reserva a través de la página web, una habitación compartida femenina",
                touch5: "Ordenador",
                feel5: "1",
                con5: "Le resulta difícil hacer el pago, porque tiene demasiados pasos.",
                ima5: "ordenadorenfadada.webp",

                
                /*** PASO #6: CONCLUSION ***/ 
                
                goal6: "Reserva la litera, aunque no está satisfecha con compartir la habitación.",
                touch6: "Ordenador (reserva OK)",
                feel6: "3",
                con6: "No sabe llegar hasta el lugar",
                ima6: "ordenadorlupa.jpg",
                
                
                
			}
		];
        
		$scope.model = $scope.Journeys[0];

	}])



