/*******************************************/
/*             PERSONA.JS                  */
/*     Datos para PERSONA TEMPLATE         */   
/*          [DIU] UX Toolkit v1.0 2019     */                        
/*          ver 1.2 26/Feb/2022            */
/*******************************************/
    
/****  README:       */
/****  Modifica los datos para las Personas      */
/****  v.1.1 Incluye nombre de tu grupo de prácticas (Grupo.ID), curso académico y enlace a github ***/
/****  Las imagenes para  'Photo'  están en carpeta ./photos **/
/****  Si se usan nuevas imágenes se deben añadir a esa carpeta **/
/****  Los valores de rating están entre 1..5 **/
/****  recursos de imágenes:  https://www.vectorstock.com/royalty-free-vectors/vectors-by_zdeneksasek ***/



angular.module("angular", [])
	.controller("controller", ["$scope", function($scope) { 
        $scope.Grupo_ID ="DIU1.ABCDEF";
        $scope.Curso ="2021/22";
        $scope.Github_ID ="https://github.com/mgea/UX-DIU-Toolkit";
        
		$scope.PersonaIndex = 0;
		$scope.Personas = [
			{		
                
                
                /*************************************/
                /**** PRIMERA PERSONA          *******/
                /*** Cambiar datos             *******/
                /*************************************/
                
                
				Id: 0,
				Name: "Juan López",
				Photo: "juan.png",
				Quote: "Viajar te abre la mente",
				Age: 35,
				Occupation: "Influencer/Comercial",
				Family: "Divorciado, con un hijo de 5 años",
				Location: "Cataluña",
				Character: "Le gusta viajar por España",
				PersonalityTraits: [
					{ Name: "Introvertido/reservado Vs Extrov/activo", Value: 4 },
					{ Name: "Realista/práctico Vs Intuición/imaginativo", Value: 1 },
					{ Name: "Racional/analitico  Vs   Emocional/impulsivo", Value: 3 },
					{ Name: "Flemático/apático  Vs   Colérico/visceral", Value: 5 }
				], 
				Goals: ["Encontrar el amor verdadero", "Llegar a los 100.000 seguidores en Instagram", "Visitar todas las ciudades de España antes de los 50 años"],
				Frustrations: ["Le gustaría cobrar más en su trabajo", "Le gustaría pasar más tiempo con su hijo"],
				Bio: "Empezó a ser influencer hace unos 7 años, cuando quedó desempleado. En un futuro le gustaría dedicarse a ello. Hace poco encontró un trabajo de comerciante, y por culpa de esto, se divorció.",
				Tech: [
					{ Name: "TIC/Internet", Value: 3 },
					{ Name: "Movil", Value: 5 },
					{ Name: "RRSS", Value: 5 },
					{ Name: "Software", Value: 3 }
					
				], 
                Contextos: "Viaja siempre que tiene oportunidad, y le gusta hacerlo con su hijo, siempre que puede.",  
				PreferredChannels: [
					{ Name: "Publicidad Tradicional", Value: 2 },
					{ Name: "Online & Social Media", Value: 5 },
					{ Name: "Recomendaciones & sugerencias", Value: 4 },
					{ Name: "Persona confianza (amigos, boca a boca)", Value: 2 }
				]
			},
			{	
                
                /*************************************/
                /**** SEGUNDA PERSONA          *******/
                /*** Cambiar datos             *******/
                /*************************************/
                
                
				Id: 1,
				Name: "Priscilla Russel",
				Photo: "priscilla.png",
				Quote: "La vida es una reacción química que solo requiere de equilibrio",
				Age: 21,
				Occupation: "Estudiante de Química en la Queen Mary University",
				Family: "Vive con sus padres",
				Location: "Londres, Inglaterra",
				Character: "Tímida pero con ganas de salir de su zona de confort",
				PersonalityTraits: [
					{ Name: "Introvertido/reservado Vs  Extrov/activo ", Value: 1 },
					{ Name: "Realista/práctico  Vs    Intuición/imaginativo", Value: 3 },
					{ Name: "Racional/analitico  Vs   Emocional/impulsivo", Value: 3 },
					{ Name: "Flemático/apático  Vs   Colérico/visceral", Value: 5 }
				], 
				Goals: ["Acabar la carrera de Química", "Conocer a su amigo de Granada, el cual conoció en el instituto por correspondencia", "Mejorar el español"],
				Frustrations: ["No conoce mucha gente"],
				Bio: "Conoció en el instituo a un chico de España por correspondencia en las clases de Español, y desde entonces siguen en contacto. Viaja a Granada para conocerlo en persona por primera vez.",
				Tech: [
					{ Name: "TIC/Internet", Value: 2 },
					{ Name: "Mobile", Value: 4 },
					{ Name: "RRSS", Value: 2 },
					{ Name: "Software", Value: 1 }
					
				], 
                Contextos:   "Viajar para conocer a su amigo de España" ,
				PreferredChannels: [
					{ Name: "Publicidad Tradicional (Ads)", Value: 1 },
					{ Name: "Online & Social Media", Value: 2 },
					{ Name: "Recomendaciones & sugerencias", Value: 2 },
					{ Name: "Persona confianza (amigos, boca a boca)", Value: 4 }
				]
			}
		];
		$scope.model = $scope.Personas[0];

	}])